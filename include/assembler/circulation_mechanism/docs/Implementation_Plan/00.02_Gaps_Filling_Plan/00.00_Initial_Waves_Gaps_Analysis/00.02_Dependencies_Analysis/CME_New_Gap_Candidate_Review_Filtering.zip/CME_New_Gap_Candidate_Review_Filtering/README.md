# CME New Gap Candidate Review / Filtering Pass

## Results

```text
input candidates: 144
keep_true_gap: 5
filtered_out: 138
review: 1
true unique gaps after grouping: 3
```
