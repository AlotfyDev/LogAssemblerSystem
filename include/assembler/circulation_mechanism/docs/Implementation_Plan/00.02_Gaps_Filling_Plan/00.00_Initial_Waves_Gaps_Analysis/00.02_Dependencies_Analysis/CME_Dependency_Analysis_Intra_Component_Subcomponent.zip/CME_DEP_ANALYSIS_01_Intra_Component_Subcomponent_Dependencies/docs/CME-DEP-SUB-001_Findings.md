# CME-DEP-SUB-001 — Findings

- Intra-component edges: **154**
- Virtual/missing dependency targets: **76**
- New gap candidates: **144**


## container_registry

- Edge count: 21
- Strong edges: 1
- New gap candidates: 19
- Sources: `diagnostic_inspection|mutation_policy|rebuild|resolution`
- Targets: `TContainerRegistryIndex|TContainerRegistryState|reports|resolution|state|views`

## reference_precalculator

- Edge count: 18
- Strong edges: 3
- New gap candidates: 16
- Sources: `locating_engine|reference_pool|supply`
- Targets: `handles|reference_pool|reports|state|validity|views`

## diagnostics

- Edge count: 17
- Strong edges: 0
- New gap candidates: 15
- Sources: `collector|export_adapters|recovery_classification`
- Targets: `collector|reports|state|views`

## container

- Edge count: 10
- Strong edges: 0
- New gap candidates: 10
- Sources: `creation_semantics|state_transitions|storage_shape`
- Targets: `reports|state|views`

## eviction

- Edge count: 10
- Strong edges: 2
- New gap candidates: 10
- Sources: `eviction_execution`
- Targets: `container_state|reference_validity|reports|safe_point|state|time_range|views`

## read_side_circulation_profile

- Edge count: 10
- Strong edges: 5
- New gap candidates: 10
- Sources: `addon_boundary|backpressure|boundary_contracts|delayed_release|diagnostics|failed_dispatch|retry`
- Targets: `admission|backpressure|failed_dispatch|post_bridge_capacity|receiver_acknowledgement|receiver_context|retry`

## communication_binding

- Edge count: 9
- Strong edges: 2
- New gap candidates: 9
- Sources: `bridge_facing_boundary|dispatch_output|ingress`
- Targets: `dispatch_output|exposure_contracts|reports|state|views`

## slot

- Edge count: 9
- Strong edges: 1
- New gap candidates: 8
- Sources: `mutation_policy|payload_residency`
- Targets: `payload_residency|reports|state|views`

## waiting_list

- Edge count: 8
- Strong edges: 0
- New gap candidates: 8
- Sources: `anti_collapse_guards|membership_lifecycle`
- Targets: `TContainerRegistryIndex|TWaitingListEntry|ordering_policy|reports|state|views`

## dispatcher

- Edge count: 9
- Strong edges: 2
- New gap candidates: 7
- Sources: `exposure_execution|release_policy`
- Targets: `exposure_execution|output_contract|reports|safe_point|state|views`

## release_recycle

- Edge count: 7
- Strong edges: 2
- New gap candidates: 7
- Sources: `reset_recycle_execution`
- Targets: `reference_release|reports|safe_point|state|views`

## capacity

- Edge count: 6
- Strong edges: 0
- New gap candidates: 6
- Sources: `capacity_profiles|horizontal_scaling|vertical_scaling`
- Targets: `reports|views`

## round_manager

- Edge count: 7
- Strong edges: 1
- New gap candidates: 6
- Sources: `membership|round_policy`
- Targets: `reports|round_policy|state|views`

## bundle_agent

- Edge count: 5
- Strong edges: 0
- New gap candidates: 5
- Sources: `topology_scaling`
- Targets: `capacity_profiles|default_empty_profile|reports|state|views`

## safe_point

- Edge count: 5
- Strong edges: 0
- New gap candidates: 5
- Sources: `evaluation`
- Targets: `reports|safe_point_state|state|state_views|views`

## ingress

- Edge count: 3
- Strong edges: 0
- New gap candidates: 3
- Sources: `placement_execution`
- Targets: `reports|state|views`
