# CME Dependency Analysis — Intra-Component / Subcomponent

## Counts

```text
subcomponent nodes: 33
dependency edges: 154
virtual/missing dependency targets: 76
new gap candidates: 144
```

## Files

```text
csv/CME-DEP-SUB-000_Subcomponent_Nodes.csv
csv/CME-DEP-SUB-001_Intra_Component_Dependency_Edges.csv
csv/CME-DEP-SUB-002_Virtual_Or_Missing_Subcomponent_Targets.csv
csv/CME-DEP-SUB-003_New_Gap_Candidates_From_Dependencies.csv
csv/CME-DEP-SUB-004_Summary_By_Parent_Component.csv
csv/CME-DEP-SUB-005_Intra_Component_Dependency_Matrix_Long.csv
csv/CME-DEP-SUB-006_Intra_Component_Dependency_Schema.csv
docs/CME-DEP-SUB-000_Method.md
docs/CME-DEP-SUB-001_Findings.md
```
