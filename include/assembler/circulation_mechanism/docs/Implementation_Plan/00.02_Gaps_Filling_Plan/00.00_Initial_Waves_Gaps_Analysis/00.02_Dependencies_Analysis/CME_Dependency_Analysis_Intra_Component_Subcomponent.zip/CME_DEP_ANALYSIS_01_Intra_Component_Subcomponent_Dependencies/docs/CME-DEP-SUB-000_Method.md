# CME-DEP-SUB-000 — Intra-Component Dependency Analysis Method

## Purpose

Defines the second dependency analysis stage: subcomponent dependencies inside each parent component.

## Edge Direction

```text
source_subcomponent → target_subcomponent
```

Means source depends on target.

## New Gap Discovery

If a dependency target is virtual/missing, the edge is marked:

```text
is_new_gap_candidate = true
```
