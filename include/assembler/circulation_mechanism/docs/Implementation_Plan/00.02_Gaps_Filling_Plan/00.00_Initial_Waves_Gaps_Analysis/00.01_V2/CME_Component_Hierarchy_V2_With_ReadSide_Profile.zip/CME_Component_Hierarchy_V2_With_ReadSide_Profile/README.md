# CME Component Hierarchy V2 With ReadSide Profile

## Update

Added full branch for component 21:

```text
ReadSide_Circulation_Profile
```

## Counts

```text
total rows: 336
root components: 21
subfolders: 36
headers: 279
read-side rows: 87
read-side subfolders: 13
read-side headers: 73
```

## Files

```text
cme_component_hierarchy_v2.csv
cme_component_hierarchy_v2_schema.csv
cme_component_summary_by_root_v2.csv
cme_header_summary_by_role_v2.csv
cme_read_side_profile_hierarchy.csv
manifest.json
README.md
```
