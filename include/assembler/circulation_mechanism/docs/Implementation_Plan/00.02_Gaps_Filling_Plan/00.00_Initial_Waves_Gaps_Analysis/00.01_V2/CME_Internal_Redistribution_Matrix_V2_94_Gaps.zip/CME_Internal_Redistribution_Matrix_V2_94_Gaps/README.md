# CME Internal Redistribution Matrix V2 — 94 Gaps

## Inputs

```text
Updated unique gaps: 94
Component hierarchy: V2 with ReadSide_Circulation_Profile
```

## Counts

```text
redistribution rows: 94
read-side rows: 24
proposed new subcomponents: 33
```

## Files

```text
cme_gap_internal_redistribution_matrix_v2_94.csv
cme_gap_internal_redistribution_matrix_v2_94_schema.csv
cme_redistribution_summary_by_component_v2_94.csv
cme_read_side_redistribution_v2_94.csv
cme_proposed_new_subcomponents_v2_94.csv
manifest.json
README.md
```
