# CME Gap Matrix CSV Package

## Files

```text
cme_gap_matrix.csv
cme_gap_matrix_schema.csv
cme_gap_summary_by_wave.csv
cme_gap_summary_by_normalized_gap.csv
```

## Purpose

This package converts the user-provided implementation gaps per initial wave into a queryable CSV model.

## Main Table Grain

One row = one gap entry in one wave.

## Query Examples

- All core CME gaps:
  - `scope_classification = in_pre_bridge_scope`
- All bridge/read-side deferred gaps:
  - `scope_classification = out_of_pre_bridge_cme_core`
- All anti-collapse guards:
  - `priority = P0-guard`
- Repeated gaps:
  - use `cme_gap_summary_by_normalized_gap.csv` where `occurrence_count > 1`

## Encoding

CSV files are encoded as UTF-8 with BOM (`utf-8-sig`) for Excel compatibility.
