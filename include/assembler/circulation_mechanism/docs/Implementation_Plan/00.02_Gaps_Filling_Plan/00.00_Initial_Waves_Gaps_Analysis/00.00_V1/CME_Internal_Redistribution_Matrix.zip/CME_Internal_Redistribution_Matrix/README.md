# CME Internal Redistribution Matrix

## Files

```text
cme_gap_internal_redistribution_matrix.csv
cme_gap_internal_redistribution_schema.csv
cme_redistribution_summary_by_action.csv
cme_redistribution_summary_by_component.csv
cme_proposed_new_subcomponents.csv
manifest.json
README.md
```

## Grain

One row = one deduplicated gap redistributed inside its mapped parent component.

## Counts

```text
gap rows: 76
proposed new subcomponents: 41
```

## Priority Logic

```text
1-create-new-subcomponents
2-update-existing
3-review
```

## Query Examples

- First create all new subcomponents:
  - `creation_priority_group = 1-create-new-subcomponents`
- Gaps under ReferencePrecalculator locating engine:
  - `parent_component_key = reference_precalculator AND target_subcomponent_key = locating_engine`
- Anti-collapse guards:
  - `target_artifact_kind = guard`
- Existing subcomponent updates:
  - `target_subcomponent_status = existing_subcomponent`
