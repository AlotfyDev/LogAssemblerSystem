# CME Component Hierarchy Expanded CSV Package

## Files

```text
cme_component_hierarchy.csv
cme_component_hierarchy_schema.csv
cme_component_summary_by_root.csv
cme_header_summary_by_role.csv
manifest.json
README.md
```

## Grain

One row = one artifact:

```text
root component
subfolder
header
```

## Counts

```text
total rows: 249
root components: 20
subfolders: 23
headers: 206
```

## Query Examples

- All headers under Dispatcher:
  - `normalized_component_key = dispatcher AND artifact_kind = header`
- All report headers:
  - `header_role = report`
- All headers inside a subfolder:
  - `local_folder = reports`
- All direct component headers:
  - `artifact_kind = header AND artifact_level = 1`
- Children of a subfolder:
  - `parent_artifact_id = <subfolder artifact_id>`

## Notes

Raw spelling from the supplied outline is preserved in `component_name_raw`.

Query normalization corrects obvious typos:

```text
Capicity → capacity
Reference_Precalulator → reference_precalculator
```
